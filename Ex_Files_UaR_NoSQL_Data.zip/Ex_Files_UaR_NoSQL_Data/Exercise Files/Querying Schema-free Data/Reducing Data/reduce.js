function(key, values, rereduce) {
  return values.length;
}